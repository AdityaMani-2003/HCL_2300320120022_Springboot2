package com.hcl.hclassessment2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.hclassessment2.entity.Cart;
import com.hcl.hclassessment2.entity.CartItem;
import com.hcl.hclassessment2.service.CartService;

@RestController
@RequestMapping("/carts")
public class CartController {

    @Autowired private CartService service;

    @PostMapping("/{customerId}")
    public Cart createCart(@PathVariable Long customerId) {
        return service.createCart(customerId);
    }

    @PostMapping("/{cartId}/items")
    public CartItem addItem(@PathVariable Long cartId,
                            @RequestParam Long productId,
                            @RequestParam Integer qty) {
        return service.addItem(cartId, productId, qty);
    }
}