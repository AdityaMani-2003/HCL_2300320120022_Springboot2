package com.hcl.hclassessment2.repository;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerRepository extends JpaRepository {
    

    
} 