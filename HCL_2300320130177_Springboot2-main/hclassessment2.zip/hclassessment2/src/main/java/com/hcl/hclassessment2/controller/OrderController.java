package com.hcl.hclassessment2.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.hclassessment2.entity.CustomerOrder;
import com.hcl.hclassessment2.repository.OrderRepository;
@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired private OrderRepository orderRepo;

    @PostMapping
    public CustomerOrder create(@RequestBody CustomerOrder o) {
        return orderRepo.save(o);
    }

    @GetMapping("/{customerId}")
    public List<CustomerOrder> list(@PathVariable Long customerId) {
        return orderRepo.findAll()
                .stream()
                .filter(o -> o.getCustomer().getId().equals(customerId))
                .toList();
    }
}
