package com.hcl.hclassessment2.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class OrderItem {
    @Id
    @GeneratedValue

    private long orderItemId;
    private CustomerOrder customerOrder;
    private Product product;
    private  Integer quantity; 
    private double price;
}
