package com.hcl.hclassessment2.entity;



import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Customer {
    @Id
    @GeneratedValue
    private long Customerid;
    private String CustomerName;
    private String email;
    private String password;
    private String mobile;
    private String City;
    


  

    
}
