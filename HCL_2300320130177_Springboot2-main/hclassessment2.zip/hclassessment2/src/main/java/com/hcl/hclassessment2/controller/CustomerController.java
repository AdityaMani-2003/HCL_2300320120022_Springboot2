package com.hcl.hclassessment2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.hclassessment2.entity.Customer;
import com.hcl.hclassessment2.repository.CustomerRepository;


@RestController
@RequestMapping("/customers")
public class CustomerController {
     @Autowired private CustomerRepository repo;

    @PostMapping
    public Customer create(@RequestBody Customer c) { return repo.save(c); }

    @GetMapping
    public List<Customer> list() { return repo.findAll(); }

    @GetMapping("/{id}")
    public Customer get(@PathVariable Long id) { return repo.findById(id).orElseThrow(); }

    @PutMapping("/{id}")
    public Customer update(@PathVariable Long id, @RequestBody Customer c) {
        c.setId(id);
        return repo.save(c);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) { repo.deleteById(id); }

  
}
