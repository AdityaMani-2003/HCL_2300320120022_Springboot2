package com.hcl.hclassessment2.entity;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Cart {
    @Id @GeneratedValue
    private long cartId;
    private Customer customer;
    private LocalDate creatDate;
    
}
