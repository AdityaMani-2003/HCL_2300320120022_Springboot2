package com.hcl.hclassessment2.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity

public class CartItem {
    @Id
    @GeneratedValue

    private long cartItemId;
    private Cart cart;
    private Product product;
    private Integer quantity;
    private double price;
    
}
