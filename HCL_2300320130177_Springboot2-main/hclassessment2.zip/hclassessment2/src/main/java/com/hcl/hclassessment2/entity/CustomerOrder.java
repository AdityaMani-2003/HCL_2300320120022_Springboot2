package com.hcl.hclassessment2.entity;

import java.time.LocalDateTime;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

public class CustomerOrder {
    @Id @GeneratedValue
    private long orderId;
    private Customer customer;
    private LocalDateTime orderDate;
    private double totalamount;
    private String orderStatus;
    
}
