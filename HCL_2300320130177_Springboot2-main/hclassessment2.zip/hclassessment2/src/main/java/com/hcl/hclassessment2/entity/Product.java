package com.hcl.hclassessment2.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
@Entity
public class Product {
     @Id
    @GeneratedValue
    private long productid;
    private String productName;
    private String description;
    private double price;
    private Integer quantity;
    private String Category;
    
}
